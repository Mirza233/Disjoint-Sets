package psa.naloga2;


public class UnionFind {
	public int[] id;
	/*public static void main(String[]Args) {
		UnionFind set = new UnionFind(1000);
		for (int i = 0; i<500;i++) {
			set.unite(i,i+1);
		}
		for (int i = 0; i<500;i++) {
		System.out.print(i);
		System.out.print("   ");
		System.out.println(set.id[i]);
		}
		}*/
	
	public UnionFind(int N) {
		id = new int[N];
		fillarray();
	}
	
	public void fillarray() {
		for (int i = 0; i<id.length;i++) {
			id[i] = i;
		}
	}
	/*
	 * Metoda sprejme index in vrne predstavnika mnozice, katere clan je index.
	 */
	public int findroot(int i) {
		while(id[i]!=i){
			i = id[id[i]];
		}
		return id[i];
	}
	
	public int find(int i) {
		int root = findroot(i);
		int j = i;
		while (id[i]!=i) {
			i = id[i];
			id[j] = root;
			j = i;
		}
		return id[i];
	}

	/*
	 * Metoda sprejme da indexa in naredi unijo
	 */
	public void unite(int p, int q) {
		int p1 = findroot(p);
		int q1 = findroot(q);
		id[q1] = p1;
	}
	
	/*
	 * Metoda vrne true, ce sta p in q v isti mnozici
	 */
	public boolean isInSameSet(int p, int q) {
		int p1 = find(p);
		int q1 = find(q);
		return (p1 == q1);
		}
}


	